"""
Real-Time Audio Streaming Server
=================================
Receives live audio from a smartphone browser via WebRTC (fastrtc),
converts frames to NumPy arrays at 16 kHz mono, and forwards them
to a pluggable ML processing pipeline.

Usage
-----
1. Install dependencies:
   pip install fastrtc fastapi uvicorn numpy

2. Run:
   python server.py

3. Open the printed URL on your smartphone browser (same WiFi).
"""

import time
import numpy as np
import uvicorn
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastrtc import Stream, StreamHandler

# ---------------------------------------------------------------------------
# ML Processing Pipeline — replace / extend this function with your model
# ---------------------------------------------------------------------------

def ml_pipeline(audio_mono_16k: np.ndarray, sample_rate: int = 16000) -> None:
    """
    Placeholder ML processing function.

    Parameters
    ----------
    audio_mono_16k : np.ndarray
        1-D float32 array of audio samples at 16 000 Hz, range [-1, 1].
    sample_rate : int
        Confirmed sample rate (always 16 000 in this pipeline).
    """
    # ---- Example: compute RMS energy ----
    rms = float(np.sqrt(np.mean(audio_mono_16k ** 2)))

    # ---- Drop-in points for real inference ----
    # e.g. onnxruntime, torch, whisper, etc.
    # result = model.run(audio_mono_16k)

    ts = time.strftime("%H:%M:%S")
    print(
        f"[{ts}]  samples={len(audio_mono_16k):6d}  "
        f"duration={len(audio_mono_16k)/sample_rate*1000:.1f} ms  "
        f"RMS={rms:.5f}"
    )


# ---------------------------------------------------------------------------
# FastRTC audio handler
# ---------------------------------------------------------------------------

TARGET_SR = 16_000


class AudioHandler(StreamHandler):
    """
    Receives raw audio chunks from the WebRTC stream.

    fastrtc delivers frames as (sample_rate, audio_array) tuples where
    audio_array has shape (channels, samples) and dtype float32.
    """

    def __init__(self):
        super().__init__()
        self._total_samples = 0
        self._start_time: float | None = None

    def receive(self, frame: tuple[int, np.ndarray]) -> None:
        sample_rate, audio = frame          # audio shape: (channels, samples)

        if self._start_time is None:
            self._start_time = time.time()
            print("\n✅  First audio frame received — streaming is live!\n")

        # --- Convert to mono float32 ---
        if audio.ndim == 2:
            audio_mono = audio.mean(axis=0).astype(np.float32)
        else:
            audio_mono = audio.astype(np.float32)

        # --- Resample to 16 kHz if needed ---
        if sample_rate != TARGET_SR:
            # Simple linear resample (swap for scipy.signal.resample for quality)
            ratio = TARGET_SR / sample_rate
            new_len = int(len(audio_mono) * ratio)
            audio_mono = np.interp(
                np.linspace(0, len(audio_mono) - 1, new_len),
                np.arange(len(audio_mono)),
                audio_mono,
            ).astype(np.float32)

        self._total_samples += len(audio_mono)

        # --- Forward to ML pipeline ---
        ml_pipeline(audio_mono, sample_rate=TARGET_SR)

    # fastrtc may call emit() to request audio to send back; we send silence
    def emit(self) -> tuple[int, np.ndarray] | None:
        return None


# ---------------------------------------------------------------------------
# FastAPI app + fastrtc Stream
# ---------------------------------------------------------------------------

app = FastAPI(title="Real-Time Audio Stream")

stream = Stream(
    handler=AudioHandler(),
    modality="audio",           # audio-only stream
    mode="receive",             # server only receives, does not send back
)

# Mount the WebRTC signalling routes provided by fastrtc
stream.mount(app)


@app.get("/", response_class=HTMLResponse)
async def index():
    """Serve the built-in client page (see client.html for the full UI)."""
    with open("client.html", "r") as f:
        return f.read()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import socket

    # Detect local IP so we can print the phone URL
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
    except Exception:
        local_ip = "127.0.0.1"
    finally:
        s.close()

    port = 8000
    print("=" * 60)
    print("  🎙️  Real-Time Audio Streaming Server")
    print("=" * 60)
    print(f"  Laptop URL  : http://localhost:{port}")
    print(f"  Phone URL   : http://{local_ip}:{port}   ← open on smartphone")
    print("=" * 60)
    print("  Waiting for smartphone connection …\n")

    uvicorn.run(app, host="0.0.0.0", port=port)
